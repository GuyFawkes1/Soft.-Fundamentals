To run this program, copy the input into input.txt and in terminal/command prompt(not powershell) run
'python3 assignment2.py <input.txt'